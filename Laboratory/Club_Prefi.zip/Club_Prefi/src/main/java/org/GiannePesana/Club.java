package org.GiannePesana;

public class Club {
    private final String[] clubTilesReference = {
            "🤮", "🍸", "🎶", "😎", "🚽", "🔐", "😎", "🍸", "🎶", "😎",
            "🚽", "🍸", "😎", "🔐", "🍸", "👧", "🎶", "🤮"
    };

    private String[] clubTiles = {
            "🤮", "🍸", "🎶", "😎", "🚽", "🔐", "😎", "🍸", "🎶", "😎",
            "🚽", "🍸", "😎", "🔐", "🍸", "👧", "🎶", "🤮"
    };

    public void updatePosition(int oldPosition, int newPosition, String symbol) {
        clubTiles[oldPosition] = clubTilesReference[oldPosition];
        if (clubTiles[newPosition].equals("👧") || clubTiles[newPosition].equals("👦")) {
            clubTiles[newPosition] = "👦👧"; // when meeting
        } else {
            clubTiles[newPosition] = symbol;
        }
    }

    public String getTile(int position) {
        return clubTiles[position];
    }

    public void display() {
        for (String tile : clubTiles) {
            System.out.print("[" + tile + "]");
        }
        System.out.println();
    }
}

